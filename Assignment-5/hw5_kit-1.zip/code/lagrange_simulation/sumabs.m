function [c,ceq] = sumabs(w, t)

c = sum( abs(w) ) - t;
ceq = [];

end

