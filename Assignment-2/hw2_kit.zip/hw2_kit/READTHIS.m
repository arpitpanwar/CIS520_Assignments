% Important instructions.
disp('ONLY SUBMIT THE CODE DIRECTORY!!');
disp('submission command (FROM WITHIN CODE DIR):');
disp('    turnin -c cis520 -p homework2 -v *');
disp('DO NOT RUN FROM THIS DIRECTORY.');
